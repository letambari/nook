<?php include 'header.php'; ?>
    <!-- Header Section End -->

	<!-- Slider Section Start -->
	<section class="page__img" style="background-image: url('branding/DSC_0546.jpg')">
		<div class="container">
			<div class="row">
				<div class="title__wrapp">
				
				</div>
			</div>
		</div>
	</section><!-- Slider Section End -->

	<!-- Portfolio Section Start -->
	<div class="section portfolio">
		<div class="container">
			<div class="row">
				<div class="button-group filters-button-group">
					<button class="button title__grey is-checked" data-filter="*">all</button>
					<!-- <button class="button title__grey" data-filter=".women">WOMEN</button>
					<button class="button title__grey" data-filter=".men">MEN</button>
					<button class="button title__grey" data-filter=".stylists">Stylists</button>
					<button class="button title__grey" data-filter=".new-faces">New Faces</button>
					<button class="button title__grey" data-filter=".teenagers">Teenagers</button>
					<button class="button title__grey" data-filter=".lifestyle">Lifestyle</button> -->


				</div>


                <div class="col-md-12" >
                	<div class="grid">
	               		<div class="grid-sizer"></div>
						<div class="grid-gutter"></div>
		            	<a href="#" class="effect-bubba grid-item grid-item__width2 new-faces women" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0131.jpg" alt="sample image">
			            
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 teenagers lifestyle men" data-category="men">
			            	<img class="img-responsive" src="branding/DSC_0120.jpg" alt="sample image">
			            	
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 new-faces stylists" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0192.jpg" alt="sample image">
			            	
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 women" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0714(2).jpg" alt="sample image">
			            	
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 women" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0794.jpg" alt="sample image">
			            	
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 teenagers lifestyle " data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0546.jpg" alt="sample image">
			            
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 new-faces stylists " data-category="women">
			            	<img class="img-responsive" src="branding/HAZEL_GRACE.jpg" alt="sample image">
			            	
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0269.jpg" alt="sample image">
			            	
	                    </a>
	                    <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0131.jpg" alt="sample image">
			            	
	                    </a>
	                </div>
                    <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0182.jpg" alt="sample image">
			            	
	                    </a>
                        <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0758.jpg" alt="sample image">
			            	
	                    </a>
                        <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0052(2).jpg" alt="sample image">
			            	
	                    </a>

                        <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0758.jpg" alt="sample image">
			            	
	                    </a>

                       
                        <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0714.jpg" alt="sample image">
			            	
	                    </a>
                        <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0758.jpg" alt="sample image">
			            	
	                    </a>
                        <a href="#" class="effect-bubba grid-item grid-item__width2 lifestyle men" data-category="women">
			            	<img class="img-responsive" src="branding/DSC_0782.jpg" alt="sample image">
			            	
	                    </a>
                       
	                </div>
	            </div>

			</div>
		</div>
	</div><!-- Portfolio Section End -->

	<!-- Call To Action Section Start -->
	<?php include 'footer.php'; ?>