<?php
$con = mysqli_connect('localhost', 'nookintl_event', 'nookintl_event', 'nookintl_event');
?>