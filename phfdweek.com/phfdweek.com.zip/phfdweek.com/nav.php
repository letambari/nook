<nav class="main__menu pull-right" id="main__nav">
							<ul class="m-menu__list clearfix">
								<li class="m-menu__list-item m-menu__list-item_active">
									<a href="index.php">Home</a>
								</li>

                                <li class="m-menu__list-item">
									<a href="about">About</a>
								</li>

                                <li class="m-menu__list-item">
									<a href="expect">What to Expect</a>
								</li>
                                
								<!--<li class="m-menu__list-item menu-item-has-children">-->
								<!--	<a href="gallery">Gallery</a>-->
									
								<!--</li>-->
							    <li class="m-menu__list-item menu-item-has-children">
									<a href="#">Reserve a seat</a>
									<ul class="m-menu__sub">
										<li class="m-menu__sub-item">
											<a href="reserve">Runway</a>
										</li>
										<li class="m-menu__sub-item">
											<a href="master">Master Class</a>
										</li>
										<!--<li class="m-menu__sub-item">-->
										<!--	<a href="exhibition">Exhibition</a>-->
										<!--</li>-->
									</ul>
								</li>
								<!--<li class="m-menu__list-item menu-item-has-children">-->
								<!--	<a href="reserve">Reserve a seat</a>-->
									
								<!--</li>-->
								<li class="m-menu__list-item">
									<a href="contacts.php">Contacts</a>
								</li>
							</ul>
						</nav>