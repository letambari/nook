<?php 
$themessage = '<div class="">
<div class="aHl"></div>
<div id=":1fb" tabindex="-1"></div>
<div id=":1f0" class="ii gt" jslog="20277; u014N:xr6bB; 4:W251bGwsbnVsbCxbXV0.">
   <div id=":1ez" class="a3s aiL msg7985106601606550211">
      <u></u>
      <div style="height:100%;margin:0;padding:0;width:100%">
         <center>
            <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_7985106601606550211bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%">
               <tbody>
                  <tr>
                     <td align="center" valign="top" id="m_7985106601606550211bodyCell" style="height:100%;margin:0;padding:0;width:100%">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                           <tbody>
                              <tr>
                                 <td align="center" valign="top" id="m_7985106601606550211templateHeader" style="background:#f7f7f7 none no-repeat center/cover;background-color:#f7f7f7;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:45px;padding-bottom:45px">
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_7985106601606550211templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                       <tbody>
                                          <tr>
                                             <td valign="top" class="m_7985106601606550211headerContainer" style="background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0">
                                                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                   <tbody>
                                                      <tr>
                                                         <td valign="top" style="padding:9px">
                                                            <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                                                               <tbody>
                                                                  <tr>
                                                                     <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                                                        <img align="center" alt="" src="https://phfdweek.com/PHFDWWEBLOGO_20211025190925.png" width="219.96" style="max-width:2672px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_7985106601606550211mcnImage CToWUd">
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                       <tbody>
                                                          <tr>
                                                             <td valign="top" style="padding-top:9px">
                                                                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_7985106601606550211mcnTextContentContainer">
                                                                   <tbody>
                                                                      <tr>
                                                                         <td valign="top" class="m_7985106601606550211mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                                                                          
                                                                         </td>
                                                                      </tr>
                                                                   </tbody>
                                                                </table>
                                                             </td>
                                                          </tr>
                                                       </tbody>
                                                    </table>
                                                 </td>
                                              </tr>
                                           </tbody>
                                        </table>
                                     </td>
                                  </tr>
                                  <tr>
                                  <td align="center" valign="top" id="m_7985106601606550211templateBody" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:36px;padding-bottom:45px">
                                        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_7985106601606550211templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                           <tbody>
                                              <tr>
                                                 <td valign="top" class="m_7985106601606550211bodyContainer" style="background:transparent none no-repeat center/cover;background-color:transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0">
                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                       <tbody>
                                                          <tr>
                                                             <td valign="top" style="padding:9px">
                                                                <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                                                                   <tbody>
                                                                      <tr>
                                                                         <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                                                            <img align="center" alt="" src="https://phfdweek.com/branding/PHFDWWEBFLYER.png" width="301.5" style="max-width:402px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_7985106601606550211mcnImage CToWUd a6T" tabindex="0">
                                                                            <div class="a6S" dir="ltr" style="opacity: 0.01; left: 413.25px; top: 514.734px;">
                                                                               <div id=":1h2" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" title="Download" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V">
                                                                                  <div class="akn">
                                                                                     <div class="aSK J-J5-Ji aYr"></div>
                                                                                  </div>
                                                                               </div>
                                                                            </div>
                                                                         </td>
                                                                      </tr>
                                                                   </tbody>
                                                                </table>
                                                             </td>
                                                          </tr>
                                                       </tbody>
                                                    </table>
                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                       <tbody>
                                                          <tr>
                                                             <td valign="top" style="padding-top:9px">
                                                                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_7985106601606550211mcnTextContentContainer">
                                                                   <tbody>
                                                                      <tr>
                                                                         <td valign="top" class="m_7985106601606550211mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center">
                                                                         <h3>Congratulations!</h3> <br>You now have a seat reserved for you for the PHFDweek Runway show. <br>
                                                                         Here is your Access Code: <strong>PHFDWEEK_'.$event_id.'</strong>.<br>

                                                                       
                                                                         </td>
                                                                      </tr>
                                                                   </tbody>
                                                                </table>
                                                             </td>
                                                          </tr>
                                                       </tbody>
                                                    </table>
                                                    
                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_7985106601606550211mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed!important">
                                                    <tbody>
                                                       <tr>
                                                          <td style="min-width:100%;padding:18px">
                                                             <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                <tbody>
                                                                   <tr>
                                                                      <td>
                                                                         <span></span>
                                                                      </td>
                                                                   </tr>
                                                                </tbody>
                                                             </table>
                                                          </td>
                                                       </tr>
                                                    </tbody>
                                                 </table>
                                              </td>
                                           </tr>
                                        </tbody>
                                     </table>
                                  </td>
                               </tr>
                              
                               </tbody>
                            </table>
                         </td>
                      </tr>
                   </tbody>
                </table>
             </center>
            </div>
          <div class="yj6qo"></div>
          <div class="adL"></div>
       </div>
    </div>
    <div id=":1ff" class="ii gt" style="display:none">
       <div id=":1fg" class="a3s aiL "></div>
    </div>
    <div class="hi"></div>
 </div>';
 ?>