.0<!-- Clients Section Start -->
<div class="section clients">
		<div class="container">
			<div class="row">
			    <div><center><h2 style='color:white;'>Sponsors</h2></center></div>
				<!--<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset15sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>-->
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/steph.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset26sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset28sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset20sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/volcan.jpg" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset24sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset21sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset30sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div><div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset31sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
					
			</div>
			<br><br>
			
			<!-- media partners -->
			<div class="row">
			    <div><center><h2 style='color:white;'>MEDIA PARTNERS</h2></center></div>
				<!--<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset15sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>-->
				<!--<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset16sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>-->
        <div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset22sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
         <div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/bella.jpeg" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
        
        
        
        	<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset32sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
        	<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/newlogonation.jpg" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
        	
        	

				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset19sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/Asset29sponsor.png" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				<div class="clients__img col-lg-2 col-md-4 col-sm-6 col-xs-12"><img src="https://phfdweek.com/sponsors/001Photography.jpg" alt="" height='70px' width='120px' style='filter: grayscale(100%);'></div>
				
				
				
			
			</div>
		</div>
	</div><!-- Clients Section End -->

	<!-- Footer Start -->
	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="footer__widgets clearfix">
					<div class="col-md-3 col-sm-6 col-xs-12 footer__social">
						<div class="footer__title">We are social</div>
						<ul class="fs__list clearfix">
							<li class="fs__list-item"><a href="https://www.facebook.com/phfdweek/" class="animation"><i class="mdi mdi-facebook"></i></a></li>
							<li class="fs__list-item"><a href="https://www.instagram.com/phfdweek/" class="animation"><i class="mdi mdi-instagram"></i></a></li>
							<li class="fs__list-item"><a href="https://twitter.com/phfdweek" class="animation"><i class="mdi mdi-twitter"></i></a></li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 footer__adres">
						<!-- <div class="footer__title">Visit us</div>
						<div class="fa__text">53 Abernathy Trace Suite 289,<br> Los Angeles</div> -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 footer__contacts">
						<div class="footer__title">Contact us</div>
						<div class="fa__tel">0803 875 3903</div>
						<a href="mailto:info@phfdweek.com">info@phfdweek.com</a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 footer__subscribe">
						<div class="footer__title">Our newsletter</div>
						<div class="footer__subscribe-wrapp">
							<input class="input input__subscribe" placeholder="Your e-mail">
							<button type="submit" class="submit__button animation"><i class="mdi mdi-arrow-right"></i></button>
						</div>
					</div>
				</div>
				<div class="footer__copyrite">© 2021 PHFDW. All Rights Reserved.</div>
			</div>
		</div>
	</footer><!-- Footer End -->

	<div class="scroll-top animation"><i class="mdi mdi-arrow-up"></i></div>



	<div class="hidden"></div>

	<!--[if lt IE 9]>
	<script src="libs/html5shiv/es5-shim.min.js"></script>
	<script src="libs/html5shiv/html5shiv.min.js"></script>
	<script src="libs/html5shiv/html5shiv-printshiv.min.js"></script>
	<script src="libs/respond/respond.min.js"></script>
	<![endif]-->

	<script src="libs/jquery/jquery-1.11.2.min.js"></script>
	<script src="libs/modernizr/modernizr.js"></script>
	<script src="libs/bootstrap/js/bootstrap.min.js"></script>
	<script src="libs/plugins-scroll/plugins-scroll.js"></script>
	<script src="libs/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="libs/izotope/isotope.pkgd.min.js"></script>
	<script src="libs/hero-slider/hero-slider.js"></script> <!-- Resource jQuery -->

	<script src="js/common.js"></script>


</body>

<!-- Mirrored from backstage.dymix.us/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 24 Oct 2021 19:55:06 GMT -->
</html>
